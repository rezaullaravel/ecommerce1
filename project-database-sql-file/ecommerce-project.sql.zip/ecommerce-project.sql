-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 07, 2022 at 03:15 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecommerce-project`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1, 'admin2', 'admin@gmail.com', NULL, '$2y$10$6cQrBlorLqFimXl252uJd.lhk2xcQX2ayTbBNaplBzM7n2TifJt9u', NULL, NULL, '202109101836mee1.png', NULL, '2021-09-10 12:36:31'),
(2, 'admin3', 'admin3@gmail.com', NULL, '$2y$10$6cQrBlorLqFimXl252uJd.lhk2xcQX2ayTbBNaplBzM7n2TifJt9u', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand_image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `brand_name`, `brand_slug`, `brand_image`, `created_at`, `updated_at`) VALUES
(5, 'Nokia', 'nokia', 'upload/brands/1710888910431150.jpg', '2021-09-14 08:46:52', '2021-09-14 08:46:52'),
(6, 'Samsung', 'samsung', 'upload/brands/1711521064714507.jpg', '2021-09-21 08:14:42', '2021-09-21 08:14:42'),
(7, 'Sony', 'sony', 'upload/brands/1711521082349032.jpg', '2021-09-21 08:14:58', '2021-09-21 08:14:58'),
(8, 'dafa', 'dafa', 'upload/brands/1723862767244222.jpg', '2022-02-04 13:40:46', '2022-02-04 13:40:46'),
(9, 'kkk', 'kkk', 'upload/brands/1726837924421394.jpg', '2022-03-09 09:49:39', '2022-03-09 09:49:39');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_icon` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_slug`, `category_icon`, `created_at`, `updated_at`) VALUES
(25, 'Boys', 'boys', 'fa fa-facebook', '2021-09-21 09:23:40', '2021-09-21 09:23:40'),
(26, 'cosmetics', 'cosmetics', 'fa fa-facebook', '2021-09-21 09:45:38', '2021-09-21 09:45:38'),
(27, 'shampoo', 'shampoo', 'fa fa-google', '2021-10-05 02:43:05', '2021-10-05 02:43:05'),
(28, 'shop', 'shop', 'fa fa-google', '2021-10-05 02:43:18', '2021-10-05 02:43:18');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `coupon_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_discount` int(11) NOT NULL,
  `coupon_validity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `coupon_name`, `coupon_discount`, `coupon_validity`, `status`, `created_at`, `updated_at`) VALUES
(1, 'BBB', 20, '10/10/2022', 1, '2021-10-31 08:19:27', '2021-10-31 08:19:27'),
(2, 'JJJ', 25, '10/10/2024', 1, '2021-11-01 06:14:53', NULL),
(4, '333', 20, '2024-02-16', 1, '2021-11-03 11:02:47', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2021_02_02_203839_create_sessions_table', 1),
(7, '2021_02_02_212221_create_admins_table', 1),
(8, '2021_09_07_152626_create_brands_table', 2),
(9, '2021_09_10_175508_create_categories_table', 3),
(10, '2021_09_14_145214_create_subcategories_table', 4),
(11, '2021_09_16_162503_create_sub_sub_categories_table', 5),
(12, '2021_09_18_133116_create_products_table', 6),
(13, '2021_10_03_134342_create_multi_imgs_table', 7),
(14, '2021_10_04_141308_create_sliders_table', 8),
(15, '2021_10_19_190000_create_wishlists_table', 9),
(16, '2021_10_31_222249_create_coupons_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `multi_imgs`
--

CREATE TABLE `multi_imgs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `photo_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `multi_imgs`
--

INSERT INTO `multi_imgs` (`id`, `product_id`, `photo_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'upload/products/multi-image/1712609840292521.jpg', '2021-10-03 08:40:18', NULL),
(2, 1, 'upload/products/multi-image/1712609840631199.jpg', '2021-10-03 08:40:19', NULL),
(3, 1, 'upload/products/multi-image/1712609840916960.jpg', '2021-10-03 08:40:19', NULL),
(4, 1, 'upload/products/multi-image/1712609841316027.jpg', '2021-10-03 08:40:19', NULL),
(5, 2, 'upload/products/multi-image/1712611572344922.png', '2021-10-03 09:07:51', NULL),
(6, 2, 'upload/products/multi-image/1712611573389398.png', '2021-10-03 09:07:52', NULL),
(7, 2, 'upload/products/multi-image/1712611574042508.png', '2021-10-03 09:07:52', NULL),
(8, 3, 'upload/products/multi-image/1712877809219811.png', '2021-10-06 07:39:34', NULL),
(9, 3, 'upload/products/multi-image/1712877809898727.jpg', '2021-10-06 07:39:34', NULL),
(10, 3, 'upload/products/multi-image/1712877810216430.jpg', '2021-10-06 07:39:35', NULL),
(11, 4, 'upload/products/multi-image/1712877916470765.jpg', '2021-10-06 07:41:16', NULL),
(12, 4, 'upload/products/multi-image/1712877916879670.jpg', '2021-10-06 07:41:16', NULL),
(13, 4, 'upload/products/multi-image/1712877917142000.jpg', '2021-10-06 07:41:17', NULL),
(14, 4, 'upload/products/multi-image/1712877918138032.png', '2021-10-06 07:41:18', NULL),
(15, 5, 'upload/products/multi-image/1712891281367273.jpg', '2021-10-06 11:13:42', NULL),
(16, 5, 'upload/products/multi-image/1712891281876883.png', '2021-10-06 11:13:43', NULL),
(17, 6, 'upload/products/multi-image/1713207941235810.jpg', '2021-10-10 12:06:52', NULL),
(18, 6, 'upload/products/multi-image/1713207941377170.jpg', '2021-10-10 12:06:52', NULL),
(19, 6, 'upload/products/multi-image/1713207941511048.jpg', '2021-10-10 12:06:52', NULL),
(20, 6, 'upload/products/multi-image/1713207941649749.jpg', '2021-10-10 12:06:52', NULL),
(21, 7, 'upload/products/multi-image/1713299810149132.jpg', '2021-10-11 12:27:05', NULL),
(22, 7, 'upload/products/multi-image/1713299810293454.jpg', '2021-10-11 12:27:05', NULL),
(23, 7, 'upload/products/multi-image/1713299810436103.jpg', '2021-10-11 12:27:05', NULL),
(24, 7, 'upload/products/multi-image/1713299810575548.jpg', '2021-10-11 12:27:05', NULL),
(25, 8, 'upload/products/multi-image/1713608047527329.jpg', '2021-10-14 09:06:23', NULL),
(26, 8, 'upload/products/multi-image/1713608047826394.jpg', '2021-10-14 09:06:23', NULL),
(27, 8, 'upload/products/multi-image/1713608048193890.jpg', '2021-10-14 09:06:24', NULL),
(28, 8, 'upload/products/multi-image/1713608048584555.jpg', '2021-10-14 09:06:24', NULL),
(29, 9, 'upload/products/multi-image/1713610417009436.jpg', '2021-10-14 09:44:03', NULL),
(30, 9, 'upload/products/multi-image/1713610417417890.jpg', '2021-10-14 09:44:03', NULL),
(31, 9, 'upload/products/multi-image/1713610417700363.jpg', '2021-10-14 09:44:04', NULL),
(32, 9, 'upload/products/multi-image/1713610418420033.jpg', '2021-10-14 09:44:04', NULL),
(33, 9, 'upload/products/multi-image/1713610418683379.jpg', '2021-10-14 09:44:04', NULL),
(34, 10, 'upload/products/multi-image/1723851561054381.jpg', '2022-02-04 10:42:39', NULL),
(35, 10, 'upload/products/multi-image/1723851561312609.jpg', '2022-02-04 10:42:39', NULL),
(36, 10, 'upload/products/multi-image/1723851561596316.jpg', '2022-02-04 10:42:39', NULL),
(37, 10, 'upload/products/multi-image/1723851561837187.jpg', '2022-02-04 10:42:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `subsubcategory_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_slug_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_qty` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_tags` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `selling_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_price` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_short_desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_long_desc` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_thambnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hot_deals` int(11) DEFAULT NULL,
  `featured` int(11) DEFAULT NULL,
  `special_offer` int(11) DEFAULT NULL,
  `special_deals` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `brand_id`, `category_id`, `subcategory_id`, `subsubcategory_id`, `product_name`, `product_slug_name`, `product_code`, `product_qty`, `product_tags`, `product_size`, `product_color`, `selling_price`, `discount_price`, `product_short_desc`, `product_long_desc`, `product_thambnail`, `hot_deals`, `featured`, `special_offer`, `special_deals`, `status`, `created_at`, `updated_at`) VALUES
(1, 5, 25, 27, 13, 'gsdzg', 'gsdzg', '12', '5', '1', '4', 'red', '4', '3', 'gagagagaagagavvzv', 'hdhdjtujjfjmjnmmbnx', 'upload/products/thambnail/1712609839751859.jpg', 1, 1, 1, 1, 1, '2021-10-03 08:40:18', NULL),
(2, 6, 26, 28, 15, 'aaaa', 'aaaa', '15', '4', 'ffffff', '30', 'green', '6', '5', 'zgfzsgg', 'shdjhdjdjdjdj', 'upload/products/thambnail/1712611571449485.jpg', 1, 1, 1, 1, 1, '2021-10-03 09:07:50', NULL),
(3, 6, 27, 29, 16, 'lkjljljk', 'lkjljljk', 'hhkjhjkhkj', 'klkjhlkjlk', 'Boys, Girls', '30', 'Red,Green,Black', '4', '2', 'jklkjljljljl;jk;k;k;k;k;', 'jljljlljlkjasfljlafjlafjljafljouaoiuwirjkk', 'upload/products/thambnail/1712877807969596.jpg', 1, 1, 1, 1, 1, '2021-10-06 07:39:33', NULL),
(4, 6, 26, 26, 14, 'bmnvnb', 'bmnvnb', '10', '5', 'Boys, Girls', '30', 'Red,Green,Black', '20', NULL, 'ggaattgatgtg', 'gsgsgsgsgsgssfgs', 'upload/products/thambnail/1712877916031222.jpg', 1, 1, 1, 1, 1, '2021-10-06 07:41:16', NULL),
(5, 7, 28, 31, 18, 'Lux soap', 'lux-soap', '1206', '5', 'soap', '30', 'Red,Green,Black', '4', '2', 'Lux is a beautiful soap.Lux is a beautiful soap.Lux is a beautiful soap.Lux is a beautiful soap.Lux is a beautiful soap.', 'Lux Soap was introduced to America in 1925 by the Lever Brothers.[6] It was a white soap packaged in pastel colors designed to be comparable to the finer French soaps, but more affordable.[7] The Lever Brothers used a marketing company named the Thompson ', 'upload/products/thambnail/1712891280066660.jpg', 1, 1, 1, 1, 1, '2021-10-06 11:13:41', NULL),
(6, 6, 27, 29, 16, 'meril', 'meril', '1010', '5', 'Boys, Girls', '30', 'Red, orrange, blue, navy blue', '100', NULL, 'lkjflaskjflakfjlasdkjfae', 'Meril Olive Oil is 100% pure and natural. Since the finest olive oil is imported from Europe the quality is second to none. After you use Meril Olive Oil, you feel your skin becoming soft and smooth. As age takes its toll, it takes away your natural skin ', 'upload/products/thambnail/1713207940949085.jpg', 1, 1, 1, 1, 1, '2021-10-10 12:06:52', NULL),
(7, 6, 25, 27, 20, 'shirt', 'shirt', '129', '6', 'Boys, Girls', '30', 'Red,Green,Black', '250', NULL, 'this shirt is very beautiful.', 'high quality shirt.high quality shirt.high quality shirt.high quality shirt.high quality shirt.high quality shirt.high quality shirt.high quality shirt.high quality shirt.high quality shirt.high quality shirt.high quality shirt.', 'upload/products/thambnail/1713299809729331.jpg', 1, 1, 1, 1, 1, '2021-10-11 12:27:05', NULL),
(8, 7, 25, 25, 9, 't shirt', 't-shirt', '120', '4', 'Boys, Girls', '30', 'Red,Green,Black', '500', '100', 'good shirt', 'this is an excellent t shirt.this is an excellent shirt.this is an excellent shirt.this is an excellent shirt.', 'upload/products/thambnail/1713608046803208.jpg', 1, 1, 1, 1, 1, '2021-10-14 09:06:22', NULL),
(9, 7, 25, 27, 20, 'sss', 'sss', '12', '4', 'Boys, Girls', '30', 'Red,Green,Black', '400', '20', 'gkfgalkfjalkfjalk', 'wellcome wellcome wellcome wellcome wellcome wellcomewellcomewellcomewellcomewellcome', 'upload/products/thambnail/1713610416460026.png', 1, 1, 1, 1, 1, '2021-10-14 09:44:02', NULL),
(10, 5, 27, 30, 21, 'clinic plus', 'clinic-plus', '123', '4', 'Boys, Girls', '30', 'Red,Green,Black', '250', '25', 'fafafgagdgdsgsdgsd', 'sghhhfdhdfhdhdfhfhdfhdfhdf', 'upload/products/thambnail/1723851560631226.jpg', 1, 1, 1, 1, 1, '2022-02-04 10:42:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('8lwbjlG6w6caw2rtxqzrMKl3c1fCpq0l4FUG5WKl', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiaXd0SmJNQ2xNdXNMZUc5ZXVRUVFubzVWckUzOERsUlRrTlJmWnVtTSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7fX0=', 1662822185);

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slider_img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `slider_img`, `title`, `description`, `status`, `created_at`, `updated_at`) VALUES
(3, 'upload/slider/1712756994874441.jpg', 'new offer', 'Text messaging, or texting, is the act of composing and sending electronic messages, typically consisting of alphabetic and numeric characters, between two or more users of mobile devices, desktops/laptops, or another type of compatible computer. Text messages may be sent over a cellular network, or may also be sent via an Internet connection.', 0, '2021-10-04 23:39:16', '2022-02-04 14:01:39'),
(4, 'upload/slider/1712757024203294.jpg', 'hot deals', 'In the 1970s Loufrani trademarked the name and his design in France while he was working as a journalist for France Soir. Competing terms were used such as smiling face and happy face before consensus was reached on the term smiley, less often spelled \"smilie', 1, '2021-10-04 23:39:44', '2021-10-06 07:16:21'),
(5, 'upload/slider/1743594241804861.jpg', 'today offer', 'Today, the smiley face has evolved from an ideogram into a template for communication and use in written language. This began with Scott Fahlman in the 1980s when he first theorized ascii characters could be used to create faces and demonstrate emotion in text.', 0, '2021-10-04 23:40:25', '2022-09-10 08:53:16'),
(6, 'upload/slider/1743594791794140.jpg', 'Prosenjit Chatterji', 'He is a famous actor in tolliwood industry.He is a famous actor in tolliwood industry.He is a famous actor in tolliwood industry.', 1, '2022-09-10 08:52:51', '2022-09-10 08:52:51'),
(7, 'upload/slider/1743595384185904.jpg', 'rgwgsgs', 'gsfgdsfgghdg', 1, '2022-09-10 09:02:16', '2022-09-10 09:02:16');

-- --------------------------------------------------------

--
-- Table structure for table `subcategories`
--

CREATE TABLE `subcategories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subcategory_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subcategories`
--

INSERT INTO `subcategories` (`id`, `category_id`, `subcategory_name`, `subcategory_slug`, `created_at`, `updated_at`) VALUES
(25, 25, 't shirt', 't shirt', '2021-09-21 09:24:04', '2021-09-21 09:24:04'),
(26, 26, 'ddddddd', 'ddddddd', '2021-09-21 09:48:41', '2021-09-21 09:48:41'),
(27, 25, 'm shirt', 'm shirt', '2021-10-03 07:13:28', '2021-10-03 07:13:28'),
(28, 26, 'cosmos', 'cosmos', '2021-10-03 09:04:19', '2021-10-03 09:04:19'),
(29, 27, 'ssshampu', 'ssshampu', '2021-10-06 06:26:28', '2021-10-06 06:26:28'),
(30, 27, 'infoinfo', 'infoinfo', '2021-10-06 06:28:26', '2021-10-06 06:28:26'),
(31, 28, 'shopxx', 'shopxx', '2021-10-06 11:10:53', '2021-10-06 11:10:53'),
(32, 28, 'shopzz', 'shopzz', '2021-10-06 11:11:08', '2021-10-06 11:11:08');

-- --------------------------------------------------------

--
-- Table structure for table `sub_sub_categories`
--

CREATE TABLE `sub_sub_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(11) NOT NULL,
  `subcategory_id` int(11) NOT NULL,
  `subsubcategory_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subsubcategory_slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sub_sub_categories`
--

INSERT INTO `sub_sub_categories` (`id`, `category_id`, `subcategory_id`, `subsubcategory_name`, `subsubcategory_slug`, `created_at`, `updated_at`) VALUES
(9, 25, 25, 't shirt-87', 't shirt-87', '2021-09-21 09:24:33', '2021-09-21 09:24:33'),
(10, 25, 25, 'saloar', 'saloar', '2021-09-21 09:39:20', '2021-09-21 09:39:20'),
(11, 26, 26, 'kkkkkkkk', 'kkkkkkkk', '2021-09-21 09:50:29', '2021-09-21 09:50:29'),
(12, 25, 25, 'tttt-s', 'tttt-s', '2021-10-03 07:12:33', '2021-10-03 07:12:33'),
(13, 25, 27, 'mmm-st', 'mmm-st', '2021-10-03 07:14:09', '2021-10-03 07:14:09'),
(14, 26, 26, 'ddddd-sub-sub', 'ddddd-sub-sub', '2021-10-03 09:05:09', '2021-10-03 09:05:09'),
(15, 26, 28, 'cosmos-m', 'cosmos-m', '2021-10-03 09:05:37', '2021-10-03 09:05:37'),
(16, 27, 29, 'ssshampu x', 'ssshampu x', '2021-10-06 06:27:02', '2021-10-06 06:27:02'),
(17, 27, 30, 'infoinfo vvv', 'infoinfo vvv', '2021-10-06 06:28:55', '2021-10-06 06:28:55'),
(18, 28, 31, 'shopxx1', 'shopxx1', '2021-10-06 11:11:43', '2021-10-06 11:11:43'),
(19, 28, 32, 'shopzz1', 'shopzz1', '2021-10-06 11:12:10', '2021-10-06 11:12:10'),
(20, 25, 27, 'mmm ssss', 'mmm ssss', '2021-10-11 12:24:04', '2021-10-11 12:24:04'),
(21, 27, 30, 'clinic plus', 'clinic plus', '2022-02-04 10:39:03', '2022-02-04 10:39:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1, 'user', 'user@gmail.com', '02254555', NULL, '$2y$10$X1i8bOTmi61eWF4b94tP4uJ7QBXxhuel33sAFJKk8ffdZs.FRWxDW', NULL, NULL, 'TYvCijhIR1SX7lVshVEaaqNp1nr5bfCN5sjkTo7EWQ3MD2CVYb0862ZLRqa9', NULL, '202109071436r3.jpg', '2021-08-23 09:53:47', '2021-09-07 09:00:56'),
(2, 'user1', 'user1@gmail.com', '01719475187', NULL, '$2y$10$.9RL31pVlK9KKWmmIMSEJugWd0kkqqRu9Gg.6klkkGjiYT0zz6Ele', NULL, NULL, 'GUiAUUxjUPhNhYqSwnenEogTw5mQVRDsaengPH83UkROPK5M47AKLH7LE8aF', NULL, NULL, '2021-09-05 08:24:34', '2021-09-05 08:24:34'),
(3, 'karim', 'karim@gmail.com', '01223', NULL, '$2y$10$bFICcmCRzIQpaftV2cpTdulw87ow1cxEQwcwkIKb5yM0h9rOgg0f6', NULL, NULL, NULL, NULL, NULL, '2022-02-04 10:34:40', '2022-02-04 10:34:40');

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wishlists`
--

INSERT INTO `wishlists` (`id`, `user_id`, `product_id`, `created_at`, `updated_at`) VALUES
(1, 1, 9, '2021-10-20 03:22:58', NULL),
(5, 1, 5, '2021-10-25 04:29:01', NULL),
(6, 1, 8, '2021-10-25 04:32:27', NULL),
(7, 1, 7, '2021-10-25 04:34:31', NULL),
(8, 1, 6, '2021-10-25 04:37:52', NULL),
(9, 3, 9, '2022-02-04 10:35:37', NULL),
(10, 3, 6, '2022-02-04 10:35:51', NULL),
(11, 3, 7, '2022-02-04 10:35:55', NULL),
(12, 3, 4, '2022-02-04 10:48:13', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `multi_imgs`
--
ALTER TABLE `multi_imgs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategories`
--
ALTER TABLE `subcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sub_sub_categories`
--
ALTER TABLE `sub_sub_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `multi_imgs`
--
ALTER TABLE `multi_imgs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subcategories`
--
ALTER TABLE `subcategories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `sub_sub_categories`
--
ALTER TABLE `sub_sub_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
